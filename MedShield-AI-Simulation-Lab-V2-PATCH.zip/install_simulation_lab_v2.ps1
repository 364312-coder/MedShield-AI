param(
    [string]$Target = $PSScriptRoot
)

$ErrorActionPreference = "Stop"

$payload = Join-Path $PSScriptRoot "payload"
$public = Join-Path $Target "public"

if (!(Test-Path (Join-Path $public "index.html"))) {
    throw "Target does not look like the MedShield-AI project root: $Target"
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $Target ("_simlab_v2_backup_" + $stamp)
New-Item -ItemType Directory -Path (Join-Path $backup "public") -Force | Out-Null

$files = @(
    "index.html",
    "app.js",
    "medshield-simulation-v2.css",
    "medshield-simulation-v2.js"
)

foreach ($name in $files) {
    $current = Join-Path $public $name
    if (Test-Path $current) {
        Copy-Item $current (Join-Path (Join-Path $backup "public") $name) -Force
    }
}

foreach ($name in $files) {
    $source = Join-Path (Join-Path $payload "public") $name
    if (!(Test-Path $source)) {
        throw "Missing payload file: $source"
    }
    Copy-Item $source (Join-Path $public $name) -Force
}

node --check (Join-Path $public "app.js")
if ($LASTEXITCODE -ne 0) { throw "app.js syntax check failed" }

node --check (Join-Path $public "medshield-simulation-v2.js")
if ($LASTEXITCODE -ne 0) { throw "medshield-simulation-v2.js syntax check failed" }

$html = Get-Content (Join-Path $public "index.html") -Raw -Encoding UTF8
if ($html -notmatch "V2-SINGLE-OWNER") { throw "V2 marker missing" }
if ($html -notmatch "id=\"sim-lab\"") { throw "Simulation lab root missing" }
if ($html -notmatch "medshield-simulation-v2.js") { throw "Simulation V2 script reference missing" }
if ($html -notmatch "medshield-simulation-v2.css") { throw "Simulation V2 stylesheet reference missing" }

Write-Host ""
Write-Host "SIMULATION LAB V2 INSTALLED" -ForegroundColor Green
Write-Host ("Backup: " + $backup)
Write-Host "V2 uses an isolated #sim-lab root; legacy #console is only a zero-height anchor."
Write-Host "Wrangler config and Worker source were not modified."
Write-Host "Restart Wrangler: npm run dev"
Write-Host "Open: http://127.0.0.1:8787/?v=simlab-v2-20260901#console"
Write-Host ""
