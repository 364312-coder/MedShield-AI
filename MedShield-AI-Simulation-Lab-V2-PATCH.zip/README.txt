MedShield-AI Simulation Lab V2
Fixes legacy console JS/CSS collisions and cache isolation.
